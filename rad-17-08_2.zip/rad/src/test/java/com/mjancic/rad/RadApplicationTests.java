package com.mjancic.rad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RadApplicationTests {

	@Test
	void contextLoads() {
	}

}
