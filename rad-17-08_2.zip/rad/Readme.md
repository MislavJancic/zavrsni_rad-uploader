todo:

ograničiti da se ne dodaju videa koja već postoje --done

dodati u trigger da ograničenje bude i po korisniku --done

popraviti tagove

dodati korisnicki unos za tagove --done

strip video extensions --implemented, needs testing

popraviti unos tagova u video snippet

dodati unos private/public u db i gui